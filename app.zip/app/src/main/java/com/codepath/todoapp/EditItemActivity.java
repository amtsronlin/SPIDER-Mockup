package com.codepath.todoapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;

public class EditItemActivity extends AppCompatActivity {
    Button btnSave;
    EditText edtItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);
        btnSave = (Button) findViewById(R.id.btnSave);
        edtItem = (EditText) findViewById(R.id.editItem);
        String item = getIntent().getStringExtra("editItem");
        edtItem.setText(item);
        edtItem.setSelection(edtItem.getText().length());
    }

    public void onSaveClick(View view) {
        Intent returnIntent = new Intent();
        returnIntent.putExtra("result",edtItem.getText().toString());
        setResult(Activity.RESULT_OK,returnIntent);
        finish();
    }
}
